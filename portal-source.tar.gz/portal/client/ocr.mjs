import { createWorker, PSM, OEM } from 'tesseract.js';
import { extractInvoiceFields,extractOrderFields } from './vendor/fp-extract.ts';

export function extractReceipt(text,kind){
 const invoice=extractInvoiceFields(text);
 const payment=extractOrderFields(text,/微信|转账时间|交易单号/.test(text)?'微信':'');
 const compact=text.replace(/\s+/g,'');
 const fields={};
 const labelledAmount=compact.match(/(?:实付金额|实付|支付金额|付款金额|价税合计|总计|合计)[^0-9]{0,4}([0-9,]+(?:\.\d{1,2})?)/)?.[1];
 // Upstream WeChat rules can mistake the '-10' in a date for a negative payment.
 // Prefer explicit amount labels, then currency, then a standalone negative amount.
 let amount=kind==='invoice'?invoice.invoiceTotalAmount:labelledAmount||compact.match(/[￥¥]([0-9,]+(?:\.\d{1,2})?)/)?.[1]||text.match(/(?:^|\n)\s*[-−]([0-9,]+\.\d{2})(?=\s|$)/)?.[1];
 if(kind==='invoice')amount=compact.match(/(?:价税合计[（(]小写[)）]?|[（(]小写[)）])[^0-9]{0,4}([0-9,]+\.\d{1,2})/)?.[1]||amount;
 if(!amount)amount=labelledAmount;
 if(amount){const v=String(amount).replace(/,/g,'');if(/^[0-9]+(?:\.\d{1,2})?$/.test(v)&&Number(v)>0&&Number(v)<=1000000)fields.amount=Number(v).toFixed(2);}
 const date=text.match(/(?:开票日期|支付时间|付款时间|交易时间|转账时间|日期)?\s*[:：]?\s*(20\d{2})\s*[-/年.]\s*(\d{1,2})\s*[-/月.]\s*(\d{1,2})(?:日)?(?:\s*(\d{1,2})\s*[:：]\s*(\d{2}))?/);
 if(date){const d=`${date[1]}-${date[2].padStart(2,'0')}-${date[3].padStart(2,'0')}`,parsed=new Date(d+'T00:00:00Z');if(!Number.isNaN(+parsed)&&parsed.toISOString().slice(0,10)===d)fields.date=d;if(date[4]&&Number(date[4])<24&&Number(date[5])<60)fields.time=date[4].padStart(2,'0')+':'+date[5];}
 fields.number=kind==='invoice'?invoice.invoiceNumber||'':payment.orderNumber||'';
 return fields;
}
export async function recognize(file,kind,onProgress){
 const worker=await createWorker('chi_sim',OEM.LSTM_ONLY,{workerPath:'/vendor/worker.min.js',corePath:'/vendor/',langPath:'/tessdata',logger:m=>{if(Number.isFinite(m.progress))onProgress(m.progress,m.status);}});
 try{await worker.setParameters({preserve_interword_spaces:'1',tessedit_pageseg_mode:PSM.AUTO});const {data}=await worker.recognize(file);return {status:'complete',text:data.text,confidence:data.confidence,fields:extractReceipt(data.text,kind)};}finally{await worker.terminate();}
}
