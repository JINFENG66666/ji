const root=document.querySelector('#app');
const money=c=>new Intl.NumberFormat('zh-CN',{style:'currency',currency:'CNY'}).format((c||0)/100);
const escape=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const today=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai'}).format(new Date());
const labels={pending:'待复核',reviewed:'已复核',returned:'需补充'};
const hashParams=new URLSearchParams(location.hash.slice(1));
const setupCode=hashParams.get('setup')||'';const inviteCode=hashParams.get('invite')||'';
if(location.hash)history.replaceState(null,'',location.pathname);
let state={user:null,config:null,view:'records',claims:[],users:[],backups:[],eligible:0,loading:true,error:'',auth:'login',invite:null,month:today().slice(0,7),search:'',department:'',status:'',draft:newDraft(),jobs:[],loadVersion:0};
function newDraft(){return {date:today(),time:'',amount:'',description:'',attachments:[],idempotency_key:crypto.randomUUID(),confirmed:false};}
async function api(path,{method='GET',body}={}){
 const r=await fetch(path,{method,credentials:'same-origin',cache:'no-store',headers:body instanceof FormData?{}:body?{'Content-Type':'application/json'}:{},body:body===undefined?undefined:body instanceof FormData?body:JSON.stringify(body)});
 const j=await r.json().catch(()=>({error:'服务器返回了意外响应，请稍后重试'}));
 if(!r.ok){if(r.status===401&&state.user){state.user=null;state.claims=[];state.users=[];state.draft=newDraft();render();}throw Error(j.error||'请求失败');}return j;
}
let toastTimer;function toast(s){const e=document.querySelector('#toast');e.textContent=s;e.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>e.classList.remove('show'),4500);}
const isAdmin=()=>state.user?.role==='admin';
const brand=()=>'<div class="brand"><span class="logo">报</span><strong>员工报销</strong><small>申报 · 汇总 · 复核</small></div>';
function authView(){
 if(!state.config?.ready)return `<div class="auth">${brand()}<div class="card"><h1>网站正在完成配置</h1><p>数据库和私有凭证存储接入后，即可开始使用。</p><button data-action="reload">重新检查</button><div class="error">${escape(state.error)}</div></div></div>`;
 const mode=setupCode&&state.config.setup?'setup':inviteCode&&state.invite?'register':'login';
 if(state.config.setup&&mode!=='setup')return `<div class="auth">${brand()}<div class="card"><h1>管理员尚未初始化</h1><p>请管理员使用专属初始化链接设置账号，完成后再邀请员工。</p><button data-action="reload">重新检查</button></div></div>`;
 return `<div class="auth">${brand()}<div class="card"><div class="eyebrow">${mode==='login'?'WELCOME BACK':'ACCOUNT SETUP'}</div><h1>${mode==='setup'?'设置你的管理账号':mode==='register'?'开通员工申报账号':'登录报销系统'}</h1><p>${mode==='setup'?'只有这个管理账号可以查看全部申报数据。':mode==='register'?'此邀请仅能使用一次，账号开通后可持续使用。':'员工查看自己的申报，管理员查看全部汇总。'}</p>${mode==='register'?`<div class="info">${escape(state.invite.department)} · ${escape(state.invite.display_name)}</div>`:''}<form id="auth-form" data-mode="${mode}">${mode==='setup'?'<label>你的姓名<input name="display_name" required maxlength="40" autocomplete="name"></label>':''}<label>登录账号<input name="username" required minlength="3" maxlength="40" pattern="[a-zA-Z0-9_.-]+" placeholder="字母、数字或下划线" autocomplete="username"></label><label>登录密码<input name="password" type="password" required ${mode==='login'?'':'minlength="10"'} maxlength="128" autocomplete="${mode==='login'?'current-password':'new-password'}" placeholder="${mode==='login'?'请输入密码':'至少 10 位'}"></label>${mode==='login'?'':'<label>再次输入密码<input name="password_confirm" type="password" required minlength="10" maxlength="128" autocomplete="new-password"></label>'}<div class="error" id="form-error">${escape(state.error)}</div><button type="submit">${mode==='login'?'登录':mode==='setup'?'创建管理账号':'开通并登录'}</button></form></div><p class="footer">申报与人工复核工具 · 所有金额以人民币记录</p></div>`;
}
function shell(content){return `<header class="topbar">${brand()}<div class="identity"><span class="avatar">${escape(state.user.display_name?.slice(0,1))}</span><span class="name">${escape(state.user.display_name)} · ${isAdmin()?'管理员':escape(state.user.department)}</span><button class="secondary small" data-action="logout">退出</button></div></header><main class="shell"><nav class="nav" aria-label="主导航">${(isAdmin()?[['records','申报汇总'],['employees','员工管理'],['archive','备份归档'],['account','账号设置']]:[['submit','提交申报'],['records','我的申报'],['account','账号设置']]).map(([v,n])=>`<button data-view="${v}" class="${state.view===v?'active':''}" ${state.view===v?'aria-current="page"':''}>${n}</button>`).join('')}</nav>${content}<div class="footer-note">仅用于费用申报与汇总，不执行打款。自动检查提供辅助线索，最终结果由管理员人工复核。</div></main>`;}
function filtered(){return state.claims.filter(c=>(!state.search||(c.display_name+' '+c.department+' '+c.description).includes(state.search))&&(!state.department||c.department===state.department)&&(!state.status||c.status===state.status));}
function row(c){return `<tr><td>${escape(c.expense_date)}${c.expense_time?'<br><small>'+escape(c.expense_time.slice(0,5))+'</small>':''}</td><td>${escape(c.department)}</td><td>${escape(c.display_name)}</td><td class="subject">${escape(c.description)}<br><span class="badge ${c.status}">${labels[c.status]||escape(c.status)}</span>${c.flags?.length?`<span class="badge pending">${c.flags.length} 项待关注</span>`:''}${c.review_note?`<div class="flag">复核备注：${escape(c.review_note)}</div>`:''}<button class="secondary small" data-detail="${c.id}">${isAdmin()?'查看与复核':'查看详情'}</button></td><td class="money">${money(c.amount_cents)}</td><td class="files">${(c.attachments||[]).map(a=>a.purged_at?'<span class="muted">凭证已归档</span>':`<button class="secondary small" data-voucher="${a.id}">${a.kind==='invoice'?'发票':'支付记录'}</button>`).join(' ')}<div class="muted">${(c.attachments||[]).length} 张凭证</div></td></tr>`;}
function table(claims){return `<div class="table-wrap"><table><thead><tr><th>时间</th><th>部门</th><th>人员姓名</th><th>事项</th><th>金额</th><th>发票照片或支付记录</th></tr></thead><tbody>${claims.map(row).join('')}</tbody></table></div>`;}
function empty(title,description=''){return `<div class="empty"><div class="symbol">▤</div><strong>${title}</strong><p>${description}</p></div>`;}
function records(){
 const list=filtered();const total=list.reduce((s,c)=>s+c.amount_cents,0),pending=list.filter(c=>c.status==='pending').length,flagged=list.filter(c=>c.flags?.length).length;
 const departments=[...new Set(state.claims.map(c=>c.department))].sort();
 const groupMap=new Map();for(const c of list){if(!groupMap.has(c.user_id))groupMap.set(c.user_id,[]);groupMap.get(c.user_id).push(c);}
 const groups=[...groupMap.values()].sort((a,b)=>b.reduce((s,c)=>s+c.amount_cents,0)-a.reduce((s,c)=>s+c.amount_cents,0));
 return `<div class="title-row"><div><div class="eyebrow">${isAdmin()?'OVERVIEW':'MY EXPENSES'}</div><h1>${isAdmin()?'每一笔申报，清楚可查':'我的费用申报'}</h1><p class="subtitle">${isAdmin()?'按员工汇总金额与次数，展开姓名查看分项和凭证。':'查看已提交的金额、凭证和人工复核结果。'}</p></div><div class="actions">${isAdmin()?`<a class="button secondary" href="/api/export.xlsx${state.month?'?month='+state.month:''}">导出 Excel</a>`:'<button data-view="submit">＋ 新建申报</button>'}<button class="secondary" data-action="refresh">刷新数据</button></div></div><div class="stats"><div class="stat primary"><label>申报总金额</label><strong>${money(total)}</strong></div><div class="stat"><label>申报次数</label><strong>${list.length}</strong> <small>次</small></div><div class="stat"><label>待人工复核</label><strong>${pending}</strong> <small>笔</small></div><div class="stat"><label>有审核疑点</label><strong>${flagged}</strong> <small>笔</small></div></div><div class="filters"><input type="month" id="month" aria-label="申报月份" value="${escape(state.month)}"><button class="secondary small" data-action="all-months">全部月份</button><input class="search" id="search" aria-label="搜索申报" placeholder="搜索姓名、部门或事项" value="${escape(state.search)}">${isAdmin()?`<select id="department" aria-label="按部门筛选"><option value="">全部部门</option>${departments.map(d=>`<option ${state.department===d?'selected':''}>${escape(d)}</option>`).join('')}</select>`:''}<select id="status" aria-label="按状态筛选"><option value="">全部状态</option>${Object.entries(labels).map(([v,l])=>`<option value="${v}" ${state.status===v?'selected':''}>${l}</option>`).join('')}</select></div>${state.loading?'<div class="card loading">正在读取申报…</div>':!list.length?`<div class="card">${empty('暂时没有匹配的申报','可调整月份、筛选条件，或提交第一笔费用。')}</div>`:isAdmin()?groups.map(items=>`<details class="person"><summary><div class="person-name"><span class="avatar">${escape(items[0].display_name.slice(0,1))}</span><div><strong>${escape(items[0].display_name)}</strong><div class="muted">${escape(items[0].department)}</div></div></div><div class="person-totals"><span class="counts muted">${items.length} 次申报</span><strong>${money(items.reduce((s,c)=>s+c.amount_cents,0))}</strong><span class="chevron">⌄</span></div></summary>${table(items)}</details>`).join(''):`<div class="card" style="padding:0">${table(list)}</div>`}<div class="note section-gap">金额与次数包含当前筛选内的所有申报状态；“已复核”表示管理员已查看，不表示已经付款。导出 Excel 按所选月份导出全部申报，不受页面搜索和状态筛选影响。</div>`;
}
function submitView(){
 const d=state.draft;
 return `<div class="title-row"><div><div class="eyebrow">NEW SUBMISSION</div><h1>提交一笔费用</h1><p class="subtitle">上传凭证，确认金额和日期，再提交给管理员。</p></div></div><div class="columns"><section class="card"><form id="claim-form"><div class="form-grid"><label>部门<input readonly value="${escape(state.user.department)}"></label><label>人员姓名<input readonly value="${escape(state.user.display_name)}"></label><label>发生日期<input type="date" data-draft="date" required value="${escape(d.date)}"></label><label>具体时间 <small>选填，按北京时间</small><input type="time" data-draft="time" value="${escape(d.time)}"></label><label class="full">报销事项<textarea data-draft="description" required maxlength="500" placeholder="例如：10 月客户拜访交通费">${escape(d.description)}</textarea></label><label class="full">申报金额（元）<input data-draft="amount" inputmode="decimal" required placeholder="0.00" value="${escape(d.amount)}"><small>可以手动输入；识别结果仅供参考，以你确认的申报金额为准。</small></label></div><h2>上传凭证</h2><div class="form-grid"><label class="upload-zone"><strong>＋ 发票照片</strong><small>选择图片后自动识别</small><input type="file" data-upload="invoice" accept="image/jpeg,image/png,image/webp" multiple></label><label class="upload-zone"><strong>＋ 支付记录</strong><small>微信、支付宝或银行截图</small><input type="file" data-upload="payment" accept="image/jpeg,image/png,image/webp" multiple></label></div><div class="limits">每笔 1–4 张，原图每张不超过 6MB。系统保存清晰压缩副本，请自行保留原始凭证。图片识别在本机浏览器进行。</div><div class="section-gap">${state.jobs.map(j=>`<div class="attachment"><span class="avatar">${j.kind==='invoice'?'票':'付'}</span><div class="details"><strong>${escape(j.name)}</strong><span id="job-${j.id}">${escape(j.status)}</span><div class="progress"><span id="progress-${j.id}" style="width:${Math.round(j.progress*100)}%"></span></div></div></div>`).join('')}${d.attachments.map(a=>`<div class="attachment"><span class="avatar">${a.kind==='invoice'?'票':'付'}</span><div class="details"><strong>${escape(a.file_name)}</strong><span>${a.ocr_status==='complete'?'已识别':'自动识别未完成，可手动填写'}</span><div>识别金额：${a.fields?.amount?'¥'+escape(a.fields.amount):'未识别'} · 日期：${escape(a.fields?.date||'未识别')}</div></div><button type="button" class="secondary small" data-remove="${a.id}">移除</button></div>`).join('')}</div><label class="section-gap" style="font-weight:400;font-size:12px"><input data-draft="confirmed" type="checkbox" ${d.confirmed?'checked':''} required style="width:auto;min-height:0"> 我已查看凭证，并确认填写的金额、日期及事项。</label><div class="error" id="form-error"></div><button type="submit" ${state.jobs.length?'disabled':''}>提交申报</button></form></section><aside class="card side-card"><h2>提交前核对</h2><dl><dt>01 · 一笔费用，一次申报</dt><dd>同一事项的发票和支付截图一起上传，避免重复计算。</dd><dt>02 · 识别后需要你确认</dt><dd>数字、日期可能识别错误，也可以直接手动填写。</dd><dt>03 · 交给管理员人工复核</dt><dd>后台会提示重复图片、金额日期差异和部分编辑元数据线索。</dd></dl><div class="note warning section-gap">编辑元数据检查不能判断是否 P 图；未发现线索也不代表图片真实。所有申报仍需人工审核。</div></aside></div>`;
}
function employees(){return `<div class="title-row"><div><div class="eyebrow">TEAM</div><h1>员工与邀请</h1><p class="subtitle">为每位员工生成专属邀请，姓名与部门绑定账号。</p></div></div><div class="columns"><section class="card"><h2>已开通账号</h2>${state.users.filter(u=>u.role==='employee').map(u=>`<div class="list-row"><div><strong>${escape(u.display_name)}</strong> <span class="badge">${u.active?'使用中':'已停用'}</span><div class="muted">${escape(u.department)} · ${escape(u.username)}</div></div><button class="secondary small" data-toggle-user="${u.id}" data-active="${!u.active}">${u.active?'停用账号':'恢复账号'}</button></div>`).join('')||empty('还没有员工账号','在右侧创建邀请，把链接发给员工开通。')}</section><section class="card"><h2>邀请员工</h2><p class="subtitle">邀请链接有效 14 天，仅能使用一次。</p><form id="invite-form" class="section-gap"><label>员工姓名<input name="display_name" required maxlength="40"></label><label>所属部门<input name="department" required maxlength="60" placeholder="例如：销售部"></label><div class="error" id="form-error"></div><button type="submit">生成邀请链接</button><div id="invite-result"></div></form></section></div>`;}
function archiveView(){return `<div class="title-row"><div><div class="eyebrow">BACKUP & RETENTION</div><h1>半年凭证，先备份再归档</h1><p class="subtitle">只清理已备份且上传超过六个月的图片，申报记录和汇总继续保留。</p></div><button class="secondary" data-action="refresh">刷新备份状态</button></div><div class="columns"><section class="card"><h2>备份记录</h2>${state.backups.map(b=>`<div class="list-row"><div><strong>${escape(new Date(b.created_at).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai'}))}</strong><div class="muted">${b.count} 张凭证 · ${b.completed?'已生成完整备份':'未完整生成或下载中'}${b.confirmed_at?' · 已确认保存':''}</div></div><div class="actions">${b.completed&&!b.confirmed_at?`<button class="secondary small" data-confirm-backup="${b.id}">确认已核对备份</button>`:''}${b.confirmed_at&&state.eligible?`<button class="danger small" data-purge="${b.id}">清理此备份内的过期图片</button>`:''}</div></div>`).join('')||empty('暂无备份记录','先下载完整备份，再核对图片和表格。')}</section><aside class="card"><h2>下载完整备份</h2><p class="subtitle">包含六列表格、人员汇总、凭证图片和校验清单。</p><a class="button section-gap" href="/api/backup.zip">下载全部数据与凭证</a><div class="note section-gap">当前有 <strong>${state.eligible}</strong> 张图片达到六个月保存期限。备份下载完成后，请先解压并核对；确认保存后才可以清理符合条件的图片。大批量下载可能需要较长时间。</div></aside></div>`;}
function account(){return `<div class="title-row"><div><div class="eyebrow">ACCOUNT</div><h1>账号设置</h1></div></div><section class="card" style="max-width:520px"><div class="value-row"><span>登录账号</span><strong>${escape(state.user.username)}</strong></div><div class="value-row"><span>姓名</span><strong>${escape(state.user.display_name)}</strong></div><div class="value-row"><span>部门</span><strong>${escape(state.user.department)}</strong></div><h2 class="section-gap">修改密码</h2><form id="password-form" class="section-gap"><label>当前密码<input name="old_password" type="password" autocomplete="current-password" required></label><label>新密码<input name="password" type="password" minlength="10" maxlength="128" autocomplete="new-password" required></label><label>再次输入新密码<input name="password_confirm" type="password" minlength="10" autocomplete="new-password" required></label><div class="error" id="form-error"></div><button type="submit">更新密码</button></form></section>`;}
function render(){
 const old=document.activeElement,focus=old?.dataset?.draft,start=old?.selectionStart,end=old?.selectionEnd;
 root.innerHTML=state.user?shell(state.view==='submit'?submitView():state.view==='employees'?employees():state.view==='archive'?archiveView():state.view==='account'?account():records()):state.loading?'<main class="loading">正在连接报销系统…</main>':authView();
 if(focus){const el=root.querySelector(`[data-draft="${focus}"]`);el?.focus();try{el?.setSelectionRange(start,end);}catch{}}
}
async function load(){
 if(!state.user)return;const version=++state.loadVersion;state.loading=true;render();
 try{
   if(state.view==='records'){const {claims}=await api('/api/claims'+(state.month?'?month='+state.month:''));if(version===state.loadVersion)state.claims=claims;}
   if(state.view==='employees'){const {users}=await api('/api/users');if(version===state.loadVersion)state.users=users;}
   if(state.view==='archive'){const b=await api('/api/backups');if(version===state.loadVersion){state.backups=b.backups;state.eligible=b.eligible_count;}}
 }catch(e){toast(e.message);}finally{if(version===state.loadVersion){state.loading=false;render();}}
}
async function start(){
 state.loading=true;render();try{state.config=await api('/api/config');if(state.config.ready){if(inviteCode){try{state.invite=await api('/api/invite/'+encodeURIComponent(inviteCode));}catch(e){state.error=e.message;}}try{const j=await api('/api/me');state.user=j.user;}catch{}}}catch(e){state.error=e.message;}
 state.loading=false;if(state.user){state.view=isAdmin()?'records':'submit';await load();}else render();
}
root.addEventListener('input',e=>{if(e.target.dataset.draft){state.draft[e.target.dataset.draft]=e.target.type==='checkbox'?e.target.checked:e.target.value;}});
root.addEventListener('change',async e=>{
 const el=e.target;
 if(el.dataset.upload){const files=Array.from(el.files||[]);for(const file of files)await addFile(file,el.dataset.upload);return;}
 if(el.id==='month'){state.month=el.value;await load();}
 if(['department','status'].includes(el.id)){state[el.id]=el.value;render();}
});
root.addEventListener('input',e=>{if(e.target.id==='search'){state.search=e.target.value;const pos=e.target.selectionStart;render();const el=document.querySelector('#search');el?.focus();el?.setSelectionRange(pos,pos);}});
root.addEventListener('click',async e=>{
 const b=e.target.closest('button,a');if(!b)return;
 try{
   if(b.dataset.view){state.view=b.dataset.view;await load();return;}
   if(b.dataset.action==='reload'){await start();return;}
   if(b.dataset.action==='logout'){await api('/api/logout',{method:'POST',body:{}});state.user=null;state.claims=[];state.users=[];state.draft=newDraft();state.jobs=[];render();return;}
   if(b.dataset.action==='refresh'){await load();return;}
   if(b.dataset.action==='all-months'){state.month='';await load();return;}
   if(b.dataset.remove){state.draft.attachments=state.draft.attachments.filter(a=>a.id!==b.dataset.remove);render();return;}
   if(b.dataset.detail){showDetail(b.dataset.detail);return;}
   if(b.dataset.voucher){showVoucher(b.dataset.voucher);return;}
   if(b.dataset.toggleUser){await api('/api/users/'+b.dataset.toggleUser,{method:'PATCH',body:{active:b.dataset.active==='true'}});toast('账号状态已更新');await load();}
   if(b.dataset.confirmBackup){if(!confirm('请先确认：你已将这份 ZIP 备份保存到本机，并已解压检查表格和图片可打开。'))return;await api('/api/backups/'+b.dataset.confirmBackup+'/confirm',{method:'POST',body:{confirmation:'已核对备份可打开'}});toast('备份已确认');await load();}
   if(b.dataset.purge){if(prompt('此操作会永久删除已备份且上传超过六个月的线上图片，申报记录继续保留。请输入：删除已备份的过期图片')!=='删除已备份的过期图片')return;const j=await api('/api/backups/'+b.dataset.purge+'/purge',{method:'POST',body:{confirmation:'删除已备份的过期图片'}});toast(`已清理 ${j.count} 张过期图片`);await load();}
 }catch(error){toast(error.message);}
});
root.addEventListener('submit',async e=>{
 e.preventDefault();const form=e.target,b=form.querySelector('button[type=submit]');if(b)b.disabled=true;const error=form.querySelector('#form-error');if(error)error.textContent='';
 const values=Object.fromEntries(new FormData(form));
 try{
   if(form.id==='auth-form'){
     const mode=form.dataset.mode;if(mode!=='login'&&values.password!==values.password_confirm)throw Error('两次输入的密码不一致');
     const j=await api('/api/'+(mode==='setup'?'setup':mode==='register'?'register':'login'),{method:'POST',body:{...values,token:setupCode,invite:inviteCode}});state.user=j.user;state.view=isAdmin()?'records':'submit';state.error='';await load();
   }
   if(form.id==='claim-form'){
     if(state.jobs.length)throw Error('请等待凭证上传和识别结束');if(!state.draft.confirmed)throw Error('请先核对并勾选确认');if(!state.draft.attachments.length)throw Error('请至少上传一张凭证');
     const d=state.draft;await api('/api/claims',{method:'POST',body:{expense_date:d.date,expense_time:d.time,description:d.description,amount:d.amount,attachments:d.attachments.map(a=>a.id),idempotency_key:d.idempotency_key}});
     state.draft=newDraft();state.view='records';toast('申报已提交，等待管理员人工复核');await load();
   }
   if(form.id==='invite-form'){const j=await api('/api/invites',{method:'POST',body:values});form.querySelector('#invite-result').innerHTML=`<div class="invite-link"><strong>请将此链接发给该员工：</strong><p>${escape(j.url)}</p><small>有效 14 天，使用一次后失效。</small></div>`;}
   if(form.id==='password-form'){if(values.password!==values.password_confirm)throw Error('两次输入的新密码不一致');await api('/api/password',{method:'POST',body:values});form.reset();toast('密码已更新，其他设备的登录已失效');}
 }catch(err){if(error)error.textContent=err.message;else toast(err.message);}finally{if(b)b.disabled=false;}
});
async function addFile(file,kind){
 if(state.draft.attachments.length+state.jobs.length>=4){toast('每笔申报最多 4 张凭证');return;}
 if(!['image/jpeg','image/png','image/webp'].includes(file.type)){toast('请使用 JPG、PNG 或 WebP 图片');return;}
 if(file.size>6*1024*1024){toast('单张原图最大 6MB，请先缩小图片');return;}
 const userId=state.user.id;const job={id:crypto.randomUUID(),name:file.name,kind,status:'上传到私有凭证空间…',progress:0};state.jobs.push(job);render();
 let a;
 try{
   const form=new FormData();form.append('kind',kind);form.append('file',file);a=(await api('/api/attachments',{method:'POST',body:form})).attachment;
   let result;
   try{
     const moduleUrl='/ocr.js?v='+__BUILD_VERSION__;const {recognize}=await import(moduleUrl);
     result=await recognize(file,kind,(progress,status)=>{job.progress=Math.max(0,Math.min(1,progress));job.status=status==='recognizing text'?'正在识别文字…':'正在准备中文识别引擎…';const el=document.querySelector('#job-'+job.id),bar=document.querySelector('#progress-'+job.id);if(el)el.textContent=job.status;if(bar)bar.style.width=Math.round(job.progress*100)+'%';});
   }catch{result={status:'failed',text:'',confidence:0,fields:{}};}
   await api('/api/attachments/'+a.id+'/ocr',{method:'PUT',body:result});
   if(state.user?.id!==userId)return;
   a={...a,ocr_status:result.status,ocr_confidence:result.confidence,fields:result.fields};state.draft.attachments.push(a);
   if(!state.draft.amount&&result.fields.amount)state.draft.amount=result.fields.amount;
   if(result.fields.date){if(state.draft.attachments.length===1)state.draft.date=result.fields.date;else if(state.draft.date!==result.fields.date)toast('两张凭证日期不同，请确认本笔费用日期');}
   if(!state.draft.time&&result.fields.time)state.draft.time=result.fields.time;
   if(result.status==='failed')toast('自动识别未完成，凭证已保存，请手动填写金额和日期');
 }catch(e){toast(e.message);if(a&&state.user?.id===userId){state.draft.attachments.push({...a,ocr_status:'failed',fields:{}});toast('凭证已上传，请手动核对金额与日期');}}
 finally{state.jobs=state.jobs.filter(x=>x.id!==job.id);render();}
}
const dialog=document.querySelector('#voucher');dialog.querySelector('.close').addEventListener('click',()=>dialog.close());
function openDialog(html){document.querySelector('#voucher-content').innerHTML=html;if(!dialog.open)dialog.showModal();}
function showVoucher(id){const a=state.claims.flatMap(c=>c.attachments||[]).find(a=>a.id===id);if(!a)return;openDialog(`<h2>${a.kind==='invoice'?'发票照片':'支付记录'}</h2><p class="subtitle">${escape(a.file_name)} · 清晰压缩副本</p><img src="/api/attachments/${a.id}" alt="${a.kind==='invoice'?'发票照片':'支付记录'}"><div class="note">${(a.flags||[]).map(escape).join('<br>')||'没有发现元数据或重复线索；这不能证明图片真实。'}<br>此处不提供官方发票验真或 P 图鉴定。</div>`);}
function showDetail(id){
 const c=state.claims.find(c=>c.id===id);if(!c)return;
 openDialog(`<h2>${escape(c.description)}</h2><p class="subtitle">${escape(c.display_name)} · ${escape(c.department)} · ${escape(c.expense_date)} ${escape(c.expense_time?.slice(0,5)||'')}</p><div class="stats" style="grid-template-columns:1fr 1fr"><div class="stat"><label>申报金额</label><strong>${money(c.amount_cents)}</strong></div><div class="stat"><label>当前状态</label><strong style="font-size:22px">${labels[c.status]}</strong></div></div><h3>自动检查摘要</h3><div class="note ${c.flags?.length?'warning':''} section-gap">${c.flags?.length?c.flags.map(f=>'• '+escape(f)).join('<br>'):'暂未发现规则检查疑点，仍需人工复核。'}<br>自动识别在员工浏览器运行，其结果未由独立服务验真；编辑元数据不能作为 P 图结论。</div><h3 class="section-gap">凭证识别记录</h3>${c.attachments.map(a=>`<div class="list-row"><div><strong>${a.kind==='invoice'?'发票':'支付记录'}</strong><div class="muted">金额：${escape(a.fields?.amount||'未识别')} · 日期：${escape(a.fields?.date||'未识别')} ${escape(a.fields?.time||'')}<br>状态：${a.ocr_status==='complete'?'识别完成，置信度 '+Math.round(a.ocr_confidence)+'%':'未完成识别'}${a.fields?.number?'<br>识别单号：'+escape(a.fields.number):''}</div></div>${a.purged_at?'<span class="muted">已归档</span>':`<button class="secondary small" data-dialog-voucher="${a.id}">查看图片</button>`}</div>`).join('')}${isAdmin()?`<form id="review-form" class="section-gap" data-id="${c.id}"><h3>人工复核</h3><label class="section-gap">复核状态<select name="status">${Object.entries(labels).map(([v,l])=>`<option value="${v}" ${c.status===v?'selected':''}>${l}</option>`).join('')}</select></label><label>复核备注<textarea name="note" maxlength="1000" placeholder="填写需补充的内容或人工核对结论">${escape(c.review_note)}</textarea></label><div class="error"></div><button type="submit">保存复核结果</button></form>`:`<div class="note section-gap">复核备注：${escape(c.review_note||'暂无备注')}。如需更正申报，请联系管理员，避免重复提交同一笔费用。</div>`}`);
}
dialog.addEventListener('click',e=>{const b=e.target.closest('[data-dialog-voucher]');if(b)showVoucher(b.dataset.dialogVoucher);});
dialog.addEventListener('submit',async e=>{if(e.target.id!=='review-form')return;e.preventDefault();const f=e.target,b=f.querySelector('button[type=submit]');b.disabled=true;try{await api('/api/claims/'+f.dataset.id+'/review',{method:'PATCH',body:Object.fromEntries(new FormData(f))});dialog.close();toast('复核结果已保存');await load();}catch(error){f.querySelector('.error').textContent=error.message;}finally{b.disabled=false;}});
start();
