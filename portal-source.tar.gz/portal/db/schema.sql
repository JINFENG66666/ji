-- Employee reimbursement portal. Run once on the new, empty project.
-- All access is through the authenticated application server, never browser service keys.
begin;
create table if not exists public.exp_users (
 id uuid primary key default gen_random_uuid(), username text not null unique,
 password_hash text not null, display_name text not null, department text not null,
 role text not null check(role in ('admin','employee')), active boolean not null default true,
 created_at timestamptz not null default now()
);
create unique index if not exists exp_single_admin on public.exp_users(role) where role='admin';
create table if not exists public.exp_sessions (
 token_hash text primary key, user_id uuid not null references public.exp_users(id),
 expires_at timestamptz not null, created_at timestamptz not null default now()
);
create index if not exists exp_sessions_user on public.exp_sessions(user_id);
create table if not exists public.exp_invites (
 id uuid primary key default gen_random_uuid(), token_hash text unique not null,
 display_name text not null, department text not null, expires_at timestamptz not null,
 used_at timestamptz, created_at timestamptz not null default now()
);
create table if not exists public.exp_claims (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references public.exp_users(id),
 idempotency_key uuid not null, expense_date date not null, expense_time time,
 display_name text not null, department text not null, description text not null,
 amount_cents integer not null check(amount_cents > 0 and amount_cents <= 100000000),
 status text not null default 'pending' check(status in ('pending','reviewed','returned')),
 review_note text not null default '', flags jsonb not null default '[]',
 created_at timestamptz not null default now(), reviewed_at timestamptz,
 unique(user_id,idempotency_key)
);
create index if not exists exp_claims_user_date on public.exp_claims(user_id,expense_date desc);
create index if not exists exp_claims_created on public.exp_claims(created_at);
create table if not exists public.exp_attachments (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references public.exp_users(id),
 claim_id uuid references public.exp_claims(id), kind text not null check(kind in ('invoice','payment')),
 file_name text not null, media_id text unique not null, format text not null,
 sha256 text not null, original_sha256 text not null, dhash text not null, bytes integer not null,
 width integer not null, height integer not null, ocr_text text not null default '',
 ocr_confidence real not null default 0, ocr_status text not null default 'not_run',
 fields jsonb not null default '{}', flags jsonb not null default '[]',
 purged_at timestamptz, created_at timestamptz not null default now()
);
create index if not exists exp_attachments_claim on public.exp_attachments(claim_id);
create index if not exists exp_attachments_hash on public.exp_attachments(sha256);
create index if not exists exp_attachments_original_hash on public.exp_attachments(original_sha256);
create index if not exists exp_attachments_user on public.exp_attachments(user_id,created_at desc);
create table if not exists public.exp_backups (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references public.exp_users(id),
 attachment_ids jsonb not null, manifest_hash text not null,
 completed boolean not null default false, confirmed_at timestamptz,
 created_at timestamptz not null default now()
);
create table if not exists public.exp_audit (
 id uuid primary key default gen_random_uuid(), user_id uuid references public.exp_users(id),
 action text not null, target_id text, detail jsonb not null default '{}',
 created_at timestamptz not null default now()
);

alter table public.exp_users enable row level security;
alter table public.exp_sessions enable row level security;
alter table public.exp_invites enable row level security;
alter table public.exp_claims enable row level security;
alter table public.exp_attachments enable row level security;
alter table public.exp_backups enable row level security;
alter table public.exp_audit enable row level security;
revoke all on public.exp_users, public.exp_sessions, public.exp_invites, public.exp_claims,
 public.exp_attachments, public.exp_backups, public.exp_audit from public, anon, authenticated;
grant select,insert,update,delete on public.exp_users, public.exp_sessions, public.exp_invites,
 public.exp_claims, public.exp_attachments, public.exp_backups, public.exp_audit to service_role;

create or replace function public.exp_register(p_user jsonb, p_invite_hash text default null)
returns jsonb language plpgsql security invoker set search_path = '' as $$
declare v_user public.exp_users; v_invite public.exp_invites;
begin
 if p_invite_hash is null then
   perform pg_advisory_xact_lock(72884611);
   if exists(select 1 from public.exp_users where role='admin') then
     raise exception 'Administrator already exists';
   end if;
   insert into public.exp_users(username,password_hash,display_name,department,role)
   values(p_user->>'username',p_user->>'password_hash',p_user->>'display_name','管理','admin') returning * into v_user;
 else
   select * into v_invite from public.exp_invites
   where token_hash=p_invite_hash and used_at is null and expires_at > now() for update;
   if not found then raise exception 'Invalid or expired invitation'; end if;
   insert into public.exp_users(username,password_hash,display_name,department,role)
   values(p_user->>'username',p_user->>'password_hash',v_invite.display_name,v_invite.department,'employee') returning * into v_user;
   update public.exp_invites set used_at=now() where id=v_invite.id;
 end if;
 return to_jsonb(v_user) - 'password_hash';
end $$;

create or replace function public.exp_submit(p_user_id uuid, p_claim jsonb, p_attachment_ids uuid[])
returns jsonb language plpgsql security invoker set search_path = '' as $$
declare v_user public.exp_users; v_claim public.exp_claims; v_count integer;
begin
 select * into v_user from public.exp_users where id=p_user_id and active;
 if not found then raise exception 'Invalid employee'; end if;
 perform pg_advisory_xact_lock(hashtextextended(p_user_id::text,0));
 select * into v_claim from public.exp_claims where user_id=p_user_id and idempotency_key=(p_claim->>'idempotency_key')::uuid;
 if found then return to_jsonb(v_claim); end if;
 if cardinality(p_attachment_ids)<1 or cardinality(p_attachment_ids)>4 then raise exception 'Attach 1 to 4 images'; end if;
 perform id from public.exp_attachments where id=any(p_attachment_ids) for update;
 select count(*) into v_count from public.exp_attachments
 where id=any(p_attachment_ids) and user_id=p_user_id and claim_id is null and purged_at is null;
 if v_count<>cardinality(p_attachment_ids) then raise exception 'Attachment ownership or state mismatch'; end if;
 insert into public.exp_claims(user_id,idempotency_key,expense_date,expense_time,display_name,department,description,amount_cents,flags)
 values(p_user_id,(p_claim->>'idempotency_key')::uuid,(p_claim->>'expense_date')::date,nullif(p_claim->>'expense_time','')::time,
 v_user.display_name,v_user.department,p_claim->>'description',(p_claim->>'amount_cents')::integer,coalesce(p_claim->'flags','[]')) returning * into v_claim;
 update public.exp_attachments set claim_id=v_claim.id where id=any(p_attachment_ids);
 insert into public.exp_audit(user_id,action,target_id) values(p_user_id,'submit',v_claim.id::text);
 return to_jsonb(v_claim);
end $$;
revoke all on function public.exp_register(jsonb,text) from public,anon,authenticated;
revoke all on function public.exp_submit(uuid,jsonb,uuid[]) from public,anon,authenticated;
grant execute on function public.exp_register(jsonb,text) to service_role;
grant execute on function public.exp_submit(uuid,jsonb,uuid[]) to service_role;
commit;
