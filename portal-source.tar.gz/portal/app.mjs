import express from 'express';
import multer from 'multer';
import sharp from 'sharp';
import ExcelJS from 'exceljs';
import { ZipArchive } from 'archiver';
import { randomUUID } from 'node:crypto';
import { Readable } from 'node:stream';
import { token,hash,equal,passwordHash,passwordMatches,requireUuid,username,text,validDate,cents,mayRead,sixMonthsAgo } from './lib/security.mjs';
import { inspectImage,distance,reviewClaim } from './lib/review.mjs';

const fail=(status,message)=>{throw Object.assign(Error(message),{status});};
const safeUser=u=>u?({id:u.id,username:u.username,display_name:u.display_name,department:u.department,role:u.role,active:u.active}):null;
const statuses=new Set(['pending','reviewed','returned']);
const safeFilename=s=>String(s).replace(/[^\p{L}\p{N}._-]/gu,'_').slice(0,100);

export function createApp({db,media,origin,setupToken='',staticDir='dist',clock=()=>new Date()}){
 const app=express();app.disable('x-powered-by');app.set('trust proxy',1);
 const secure=new URL(origin).protocol==='https:';
 const limiters=new Map();let uploadCount=0;
 const limit=(key,max,ms=60000)=>{
   const now=Date.now();let item=limiters.get(key);
   if(!item||item.end<now)item={n:0,end:now+ms};
   item.n++;limiters.set(key,item);
   if(limiters.size>5000)for(const [k,v]of limiters)if(v.end<now)limiters.delete(k);
   if(item.n>max)fail(429,'操作较频繁，请稍后重试');
 };
 app.use((req,res,next)=>{
   res.set({'X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','X-Frame-Options':'DENY',
   'Permissions-Policy':'camera=(), microphone=(), geolocation=()',
   'Content-Security-Policy':"default-src 'self'; script-src 'self' 'wasm-unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' blob: data:; worker-src 'self' blob:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'"});
   if(secure)res.set('Strict-Transport-Security','max-age=31536000');
   if(req.path.startsWith('/api/'))res.set('Cache-Control','no-store');
   next();
 });
 app.use('/api',(req,res,next)=>{
   if(!['GET','HEAD','OPTIONS'].includes(req.method)){
     if(req.headers.origin&&req.headers.origin!==origin)return res.status(403).json({error:'请从本网站提交请求'});
     if(req.headers['sec-fetch-site']&& !['same-origin','none'].includes(req.headers['sec-fetch-site']))return res.status(403).json({error:'不允许跨站提交'});
   }next();
 });
 app.use(express.json({limit:'96kb'}));
 const ready=(req,res,next)=>{if(!db||!media)return res.status(503).json({error:'网站尚未完成后台配置，请稍后使用'});next();};
 async function session(req,res,next){
   const raw=(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('expense_session='))?.slice(16);
   if(!raw||! /^[A-Za-z0-9_-]{40,50}$/.test(raw))fail(401,'请先登录');
   const [s]=await db.rows('exp_sessions',{token_hash:'eq.'+hash(raw),expires_at:'gt.'+clock().toISOString()});
   if(!s)fail(401,'登录已过期，请重新登录');
   const [u]=await db.rows('exp_users',{id:'eq.'+s.user_id,active:'eq.true'});
   if(!u)fail(401,'账号已停用或不存在');req.user=u;req.sessionHash=hash(raw);next();
 }
 const admin=(req,res,next)=>{if(req.user.role!=='admin')return res.status(403).json({error:'仅管理员可查看此内容'});next();};
 async function login(res,u){
   const raw=token();await db.insert('exp_sessions',{token_hash:hash(raw),user_id:u.id,expires_at:new Date(+clock()+7*86400000).toISOString()});
   res.cookie('expense_session',raw,{httpOnly:true,secure,sameSite:'strict',maxAge:7*86400000,path:'/'});
   return safeUser(u);
 }
 async function all(table,query={}){
   const out=[];for(let offset=0;offset<100000;offset+=500){const rows=await db.rows(table,{order:'id.asc',...query,limit:'500',offset:String(offset)});out.push(...rows);if(rows.length<500)return out;}
   fail(413,'数据量过大，请按月份导出');
 }
 async function claimsFor(req){
   const query={order:'expense_date.desc,id.desc'};
   if(req.user.role!=='admin')query.user_id='eq.'+req.user.id;
   const month=req.query.month;
   if(month){if(!/^\d{4}-(0[1-9]|1[0-2])$/.test(month))fail(400,'无效月份');const [y,m]=month.split('-').map(Number);query.and=`(expense_date.gte.${month}-01,expense_date.lt.${new Date(Date.UTC(y,m,1)).toISOString().slice(0,10)})`;}
   const claims=await all('exp_claims',query);
   if(!claims.length)return [];
   const attachmentQuery={select:'id,user_id,claim_id,kind,file_name,bytes,width,height,ocr_status,ocr_confidence,fields,flags,created_at,purged_at'};
   if(req.user.role!=='admin')attachmentQuery.user_id='eq.'+req.user.id;
   const attachments=await all('exp_attachments',attachmentQuery);
   const grouped=new Map();for(const a of attachments){if(!grouped.has(a.claim_id))grouped.set(a.claim_id,[]);grouped.get(a.claim_id).push(a);}
   return claims.map(c=>({...c,attachments:grouped.get(c.id)||[]}));
 }
 async function attachmentFor(req){const [a]=await db.rows('exp_attachments',{id:'eq.'+requireUuid(req.params.id)});if(!a||!mayRead(req.user,a))fail(404,'没有找到该凭证');return a;}
 async function audit(u,action,id,detail={}){await db.insert('exp_audit',{user_id:u.id,action,target_id:String(id),detail});}
 app.get('/health',(req,res)=>res.json({ok:true}));
 app.get('/api/config',async(req,res)=>{
   if(!db||!media)return res.json({ready:false,setup:false});
   try{const admins=await db.rows('exp_users',{role:'eq.admin',select:'id',limit:'1'});res.json({ready:true,setup:!admins.length});}catch{res.status(503).json({ready:false,error:'数据库结构尚未配置完成'});}
 });
 app.post('/api/setup',ready,async(req,res)=>{
   limit('setup:'+req.ip,5);
   if(!setupToken||!equal(req.body.token,setupToken))fail(403,'初始化链接无效');
   const data={username:username(req.body.username),password_hash:await passwordHash(req.body.password),display_name:text(req.body.display_name,40)||'管理员'};
   const u=await db.rpc('exp_register',{p_user:data,p_invite_hash:null});res.status(201).json({user:await login(res,u)});
 });
 app.post('/api/login',ready,async(req,res)=>{
   const name=username(req.body.username);limit('login-ip:'+req.ip,120);limit('login:'+name,10);
   const [u]=await db.rows('exp_users',{username:'eq.'+name});
   if(!u||!u.active||!await passwordMatches(req.body.password,u.password_hash))fail(401,'账号或密码不正确');
   res.json({user:await login(res,u)});
 });
 app.get('/api/invite/:code',ready,async(req,res)=>{
   limit('invite:'+req.ip,60);if(!/^[A-Za-z0-9_-]{40,50}$/.test(req.params.code))fail(404,'邀请无效');
   const [v]=await db.rows('exp_invites',{token_hash:'eq.'+hash(req.params.code),used_at:'is.null',expires_at:'gt.'+clock().toISOString(),select:'display_name,department,expires_at'});
   if(!v)fail(404,'邀请已失效或已被使用');res.json(v);
 });
 app.post('/api/register',ready,async(req,res)=>{
   limit('register:'+req.ip,30);if(!/^[A-Za-z0-9_-]{40,50}$/.test(req.body.invite||''))fail(400,'需要有效邀请');
   const u=await db.rpc('exp_register',{p_user:{username:username(req.body.username),password_hash:await passwordHash(req.body.password)},p_invite_hash:hash(req.body.invite)});
   res.status(201).json({user:await login(res,u)});
 });
 app.use('/api',ready,session);
 app.get('/api/me',(req,res)=>res.json({user:safeUser(req.user)}));
 app.post('/api/logout',async(req,res)=>{await db.delete('exp_sessions',{token_hash:'eq.'+req.sessionHash});res.clearCookie('expense_session',{path:'/',httpOnly:true,secure,sameSite:'strict'}).json({ok:true});});
 app.post('/api/password',async(req,res)=>{
   limit('password:'+req.user.id,5);if(!await passwordMatches(req.body.old_password,req.user.password_hash))fail(400,'当前密码不正确');
   const p=await passwordHash(req.body.password);await db.patch('exp_users',{id:'eq.'+req.user.id},{password_hash:p});await db.delete('exp_sessions',{user_id:'eq.'+req.user.id});
   await audit(req.user,'password_changed',req.user.id);res.json({user:await login(res,{...req.user,password_hash:p})});
 });
 app.get('/api/claims',async(req,res)=>res.json({claims:await claimsFor(req)}));
 const upload=multer({storage:multer.memoryStorage(),limits:{fileSize:6*1024*1024,files:1,fields:1,fieldSize:30}}).single('file');
 app.post('/api/attachments',(req,res,next)=>{limit('upload:'+req.user.id,30);if(uploadCount>=3)return res.status(429).json({error:'图片处理繁忙，请稍后重试'});upload(req,res,next);},async(req,res)=>{
   if(!req.file)fail(400,'请选择一张图片');if(!['invoice','payment'].includes(req.body.kind))fail(400,'请选择发票或支付记录类型');
   uploadCount++;
   try{
     const info=await inspectImage(req.file.buffer);
     // Inspect original metadata first; retain a clear compressed copy within free storage capacity.
     let stored;for(const quality of [88,76,64]){stored=await sharp(req.file.buffer,{limitInputPixels:24_000_000}).rotate().resize({width:2400,height:2400,fit:'inside',withoutEnlargement:true}).jpeg({quality,mozjpeg:true}).toBuffer();if(stored.length<=750000)break;}
     if(stored.length>750000)fail(400,'图片内容过于复杂，请裁掉无关区域后重试');
     const prior=await all('exp_attachments',{select:'id,sha256,original_sha256,dhash,claim_id',purged_at:'is.null'});
     if(prior.some(a=>a.original_sha256===info.sha256||a.sha256===hash(stored)))info.flags.push('与已有凭证文件完全重复，请人工核对是否重复申报');
     else if(prior.some(a=>distance(a.dhash,info.dhash)<=3))info.flags.push('与已有凭证图像较相似，可能是相同模板或重复截图，请人工核对');
     const id=randomUUID();const result=await media.upload(stored,id);
     let record;
     try{[record]=await db.insert('exp_attachments',{id,user_id:req.user.id,kind:req.body.kind,file_name:safeFilename(req.file.originalname),media_id:result.public_id,format:'jpg',sha256:hash(stored),original_sha256:info.sha256,dhash:info.dhash,bytes:stored.length,width:info.width,height:info.height,flags:info.flags});}
     catch(e){try{await media.remove({media_id:result.public_id});}catch{}throw e;}
     const {media_id,original_sha256,dhash,...safe}=record;res.status(201).json({attachment:safe});
   }finally{uploadCount--;}
 });
 app.put('/api/attachments/:id/ocr',async(req,res)=>{
   const a=await attachmentFor(req);if(a.user_id!==req.user.id||a.claim_id)fail(409,'已提交的凭证不能更改识别结果');
   const fields={};if(req.body.fields?.amount){try{fields.amount=(cents(req.body.fields.amount)/100).toFixed(2);}catch{}}
   if(validDate(req.body.fields?.date))fields.date=req.body.fields.date;
   if(/^([01]\d|2[0-3]):[0-5]\d$/.test(req.body.fields?.time||''))fields.time=req.body.fields.time;
   fields.number=text(req.body.fields?.number,40);
   const status=req.body.status==='complete'?'complete':'failed';
   await db.patch('exp_attachments',{id:'eq.'+a.id},{ocr_text:text(req.body.text,12000),ocr_confidence:Math.max(0,Math.min(100,Number(req.body.confidence)||0)),ocr_status:status,fields});res.json({ok:true});
 });
 app.get('/api/attachments/:id',async(req,res)=>{
   const a=await attachmentFor(req);if(a.purged_at)fail(410,'该凭证已备份归档，请从备份中查看');
   const data=await media.download(a);res.set({'Content-Type':'image/jpeg','Cache-Control':'private, no-store','Content-Disposition':`inline; filename="${a.id}.jpg"`});res.end(data);
 });
 app.get('/api/attachments/:id/ocr',async(req,res)=>{
   const a=await attachmentFor(req);res.json({text:a.ocr_text,status:a.ocr_status,confidence:a.ocr_confidence,fields:a.fields});
 });
 app.post('/api/claims',async(req,res)=>{
   limit('submit:'+req.user.id,30);
   if(!validDate(req.body.expense_date))fail(400,'请选择有效的费用日期');
   const description=text(req.body.description,500);if(!description)fail(400,'请填写报销事项');
   const ids=req.body.attachments;if(!Array.isArray(ids)||ids.length<1||ids.length>4||new Set(ids).size!==ids.length)fail(400,'请上传 1–4 张凭证');ids.forEach(requireUuid);
   const attachments=await db.rows('exp_attachments',{id:'in.('+ids.join(',')+')'});
   if(attachments.length!==ids.length||attachments.some(a=>a.user_id!==req.user.id))fail(404,'凭证不存在');
   const expenseTime=req.body.expense_time||'';if(expenseTime&&!/^([01]\d|2[0-3]):[0-5]\d$/.test(expenseTime))fail(400,'无效的费用时间');
   const claim={expense_date:req.body.expense_date,expense_time:expenseTime,description,amount_cents:cents(req.body.amount),idempotency_key:requireUuid(req.body.idempotency_key)};
   claim.flags=reviewClaim(claim,attachments,clock());
   // Recheck exact duplicates at submission, including uploads which raced each other.
   const hashes=attachments.map(a=>a.original_sha256).filter(Boolean);
   if(hashes.length){const matches=await all('exp_attachments',{original_sha256:'in.('+hashes.join(',')+')',select:'id,claim_id'});if(matches.some(a=>a.claim_id&&!ids.includes(a.id)))claim.flags.push('此凭证与其他已提交申报重复，请管理员复核');}
   const result=await db.rpc('exp_submit',{p_user_id:req.user.id,p_claim:claim,p_attachment_ids:ids});res.status(201).json({claim:result});
 });
 app.patch('/api/claims/:id/review',admin,async(req,res)=>{
   const id=requireUuid(req.params.id);if(!statuses.has(req.body.status))fail(400,'无效状态');
   const note=text(req.body.note,1000);if(req.body.status==='returned'&&!note)fail(400,'请填写需要补充或修改的内容');
   const rows=await db.patch('exp_claims',{id:'eq.'+id},{status:req.body.status,review_note:note,reviewed_at:clock().toISOString()});if(!rows.length)fail(404,'记录不存在');
   await audit(req.user,'review',id,{status:req.body.status,note});res.json({ok:true});
 });
 app.get('/api/users',admin,async(req,res)=>res.json({users:(await all('exp_users',{select:'id,username,display_name,department,role,active,created_at'}))}));
 app.post('/api/invites',admin,async(req,res)=>{
   const name=text(req.body.display_name,40),department=text(req.body.department,60);if(!name||!department)fail(400,'请填写姓名和部门');
   const raw=token();await db.insert('exp_invites',{token_hash:hash(raw),display_name:name,department,expires_at:new Date(+clock()+14*86400000).toISOString()});
   await audit(req.user,'invite_created',name,{department});res.status(201).json({url:origin+'/#invite='+raw,expires_days:14});
 });
 app.patch('/api/users/:id',admin,async(req,res)=>{
   const id=requireUuid(req.params.id);const [u]=await db.rows('exp_users',{id:'eq.'+id});if(!u)fail(404,'账号不存在');
   if(u.role==='admin')fail(400,'此处不能修改管理员账号');const changes={};
   if(typeof req.body.active==='boolean')changes.active=req.body.active;
   if(text(req.body.department,60))changes.department=text(req.body.department,60);
   await db.patch('exp_users',{id:'eq.'+id},changes);if(changes.active===false)await db.delete('exp_sessions',{user_id:'eq.'+id});
   await audit(req.user,'employee_changed',id,changes);res.json({ok:true});
 });
 async function workbook(claims,relative=false){
   const w=new ExcelJS.Workbook();w.creator='员工报销汇总';const s=w.addWorksheet('申报明细');
   s.columns=[{header:'时间',key:'date',width:15},{header:'部门',key:'department',width:18},{header:'人员姓名',key:'name',width:16},{header:'事项',key:'description',width:42},{header:'金额',key:'amount',width:16},{header:'发票照片或支付记录',key:'files',width:58}];
   s.getRow(1).font={bold:true,color:{argb:'FFFFFFFF'}};s.getRow(1).fill={type:'pattern',pattern:'solid',fgColor:{argb:'FF205B48'}};s.views=[{state:'frozen',ySplit:1}];
   for(const c of claims){s.addRow({date:c.expense_date+(c.expense_time?' '+c.expense_time.slice(0,5):''),department:c.department,name:c.display_name,description:c.description,amount:c.amount_cents/100,files:c.attachments.map(a=>a.purged_at?'已归档：'+a.id:relative?'vouchers/'+a.id+'.jpg':origin+'/api/attachments/'+a.id).join('\n')});}
   s.getColumn('amount').numFmt='¥#,##0.00';s.getColumn('files').alignment={wrapText:true};
   s.autoFilter={from:'A1',to:'F1'};
   const summary=w.addWorksheet('人员汇总');summary.columns=[{header:'部门',key:'department',width:20},{header:'姓名',key:'name',width:18},{header:'申报次数',key:'count',width:16},{header:'申报总金额',key:'amount',width:20}];
   const groups=new Map();for(const c of claims){const g=groups.get(c.user_id)||{department:c.department,name:c.display_name,count:0,amount:0};g.count++;g.amount+=c.amount_cents;groups.set(c.user_id,g);}
   for(const g of groups.values())summary.addRow({...g,amount:g.amount/100});summary.getRow(1).font={bold:true};summary.getColumn('amount').numFmt='¥#,##0.00';return w;
 }
 app.get('/api/export.xlsx',admin,async(req,res)=>{
   const claims=await claimsFor(req);const w=await workbook(claims);res.set({'Content-Type':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','Content-Disposition':'attachment; filename="expenses.xlsx"'});await w.xlsx.write(res);res.end();
 });
 app.get('/api/backup.zip',admin,async(req,res)=>{
   const claims=await claimsFor({user:req.user,query:{}});
   const full=await all('exp_attachments',{purged_at:'is.null',select:'id,user_id,claim_id,kind,file_name,media_id,format,sha256,original_sha256,bytes'});
   const manifest={backup_id:randomUUID(),created_at:clock().toISOString(),copies:'Clear compressed copies; original upload hashes retained as metadata',claims,files:full.map(a=>({id:a.id,user_id:a.user_id,claim_id:a.claim_id,kind:a.kind,file_name:a.file_name,path:'vouchers/'+a.id+'.jpg',sha256:a.sha256,original_sha256:a.original_sha256,bytes:a.bytes}))};
   const manifestText=JSON.stringify(manifest,null,2);const [backup]=await db.insert('exp_backups',{id:manifest.backup_id,user_id:req.user.id,attachment_ids:full.map(a=>a.id),manifest_hash:hash(manifestText)});
   res.set({'Content-Type':'application/zip','Content-Disposition':`attachment; filename="expense-backup-${backup.id}.zip"`});
   const archive=new ZipArchive({zlib:{level:3}});archive.on('error',()=>res.destroy());res.on('close',()=>{if(!res.writableFinished)archive.abort();});
   const sent=new Promise((resolve,reject)=>{res.once('finish',resolve);res.once('close',()=>{if(!res.writableFinished)reject(Error('Download interrupted'));});});sent.catch(()=>{});archive.pipe(res);
   const append=async(data,name)=>new Promise((resolve,reject)=>{
     const entry=e=>{if(e.name===name){cleanup();resolve();}};const error=e=>{cleanup();reject(e);};
     const close=()=>{if(!res.writableFinished)error(Error('Download interrupted'));};
     const cleanup=()=>{archive.off('entry',entry);archive.off('error',error);res.off('close',close);};
     archive.on('entry',entry);archive.once('error',error);res.once('close',close);archive.append(data,{name});
   });
   archive.append(manifestText,{name:'manifest.json'});
   archive.append(hash(manifestText)+'  manifest.json\n',{name:'MANIFEST.SHA256'});
   archive.append('备份说明\n本备份包括原始上传图片的清晰压缩副本、表格与校验清单。请解压并确认图片和表格可打开，再到网站归档管理中确认备份。归档只清理超过六个月的线上图片，申报记录和金额汇总继续保留。\n',{name:'README.txt'});
   const w=await workbook(claims,true);archive.append(Buffer.from(await w.xlsx.writeBuffer()),{name:'expenses.xlsx'});
   try{for(const a of full){if(res.destroyed)throw Error('Download interrupted');const data=await media.download(a);if(hash(data)!==a.sha256)throw Error('Backup integrity mismatch');await append(data,'vouchers/'+a.id+'.jpg');}await archive.finalize();await sent;
     await db.patch('exp_backups',{id:'eq.'+backup.id},{completed:true});
   }catch{archive.abort();res.destroy();}
 });
 app.get('/api/backups',admin,async(req,res)=>{
   const backups=await all('exp_backups',{order:'created_at.desc'});const eligible=await all('exp_attachments',{created_at:'lt.'+sixMonthsAgo(clock()).toISOString(),purged_at:'is.null',select:'id,bytes'});
   res.json({backups:backups.map(b=>({...b,count:b.attachment_ids.length,attachment_ids:undefined})),eligible_count:eligible.length,eligible_bytes:eligible.reduce((s,a)=>s+a.bytes,0)});
 });
 app.post('/api/backups/:id/confirm',admin,async(req,res)=>{
   if(req.body.confirmation!=='已核对备份可打开')fail(400,'请先下载并核对备份文件');const id=requireUuid(req.params.id);
   const [b]=await db.rows('exp_backups',{id:'eq.'+id,completed:'eq.true'});if(!b)fail(400,'备份未完整生成');
   await db.patch('exp_backups',{id:'eq.'+id},{confirmed_at:clock().toISOString()});await audit(req.user,'backup_confirmed',id);res.json({ok:true});
 });
 app.post('/api/backups/:id/purge',admin,async(req,res)=>{
   if(req.body.confirmation!=='删除已备份的过期图片')fail(400,'需要明确确认删除');const [b]=await db.rows('exp_backups',{id:'eq.'+requireUuid(req.params.id),completed:'eq.true'});
   if(!b?.confirmed_at)fail(400,'请先确认备份已保存并可打开');
   const rows=await all('exp_attachments',{created_at:'lt.'+sixMonthsAgo(clock()).toISOString(),purged_at:'is.null'});const allowed=new Set(b.attachment_ids);let count=0;
   for(const a of rows){if(!allowed.has(a.id))continue;await media.remove(a);await db.patch('exp_attachments',{id:'eq.'+a.id},{purged_at:clock().toISOString()});count++;}
   await audit(req.user,'purge_archived_media',b.id,{count});res.json({count});
 });
 app.get('/api/audit',admin,async(req,res)=>res.json({events:await db.rows('exp_audit',{order:'created_at.desc',limit:'100'})}));
 app.use('/api',(req,res)=>res.status(404).json({error:'接口不存在'}));
 app.use(express.static(staticDir,{maxAge:'1h',setHeaders:(res,p)=>{if(p.endsWith('index.html'))res.set('Cache-Control','no-store');}}));
 app.use((req,res)=>res.status(404).send('页面不存在'));
 app.use((e,req,res,next)=>{
   if(res.headersSent)return res.destroy();
   const status=e.code==='LIMIT_FILE_SIZE'?400:(e.status||500);
   const message=e.code==='LIMIT_FILE_SIZE'?'每张原图最大 6MB':status>=500?'服务暂时不可用，请稍后重试':e.message;
   if(status>=500)console.error('request_failed',{path:req.path,status,code:e.code||'internal'});
   res.status(status).json({error:message});
 });
 return app;
}
