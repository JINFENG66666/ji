import {randomUUID} from 'node:crypto';
export class FakeDB {
 constructor(tables){this.tables=tables;}
 async rows(table,q={}){
   let rows=this.tables[table]||[];
   rows=rows.filter(r=>Object.entries(q).every(([k,v])=>{
     if(['select','order','limit','offset','and'].includes(k))return true;
     if(v==='is.null')return r[k]==null;if(v==='eq.true')return r[k]===true;
     if(v.startsWith('eq.'))return String(r[k])===v.slice(3);
     if(v.startsWith('gt.'))return r[k]>v.slice(3);if(v.startsWith('lt.'))return r[k]<v.slice(3);
     if(v.startsWith('in.('))return v.slice(4,-1).split(',').includes(String(r[k]));return true;
   }));
   rows=rows.slice(Number(q.offset||0),Number(q.offset||0)+Number(q.limit||rows.length||1));
   return structuredClone(rows.map(r=>q.select&&q.select!=='*'?Object.fromEntries(q.select.split(',').map(k=>[k,r[k]])):r));
 }
 async insert(table,data){const row={id:randomUUID(),created_at:'2026-10-31T00:00:00Z',...data};(this.tables[table]||=[]).push(row);return [structuredClone(row)];}
 async patch(table,q,data){const rows=await this.rows(table,q);for(const r of this.tables[table]||[])if(rows.some(x=>x.id?x.id===r.id:x.token_hash===r.token_hash))Object.assign(r,data);return rows.map(r=>({...r,...data}));}
 async delete(table,q){const rows=await this.rows(table,q);this.tables[table]=(this.tables[table]||[]).filter(r=>!rows.some(x=>x.id?x.id===r.id:x.token_hash===r.token_hash));return rows;}
 async rpc(name,data){
   if(name==='exp_submit'){
     const old=(this.tables.exp_claims||[]).find(c=>c.user_id===data.p_user_id&&c.idempotency_key===data.p_claim.idempotency_key);if(old)return structuredClone(old);
     const atts=(this.tables.exp_attachments||[]).filter(a=>data.p_attachment_ids.includes(a.id));
     if(atts.length!==data.p_attachment_ids.length||atts.some(a=>a.user_id!==data.p_user_id||a.claim_id))throw Object.assign(Error('凭证已使用'),{status:400});
     const u=this.tables.exp_users.find(u=>u.id===data.p_user_id);
     const [c]=await this.insert('exp_claims',{user_id:u.id,display_name:u.display_name,department:u.department,status:'pending',review_note:'',...data.p_claim});
     atts.forEach(a=>a.claim_id=c.id);return c;
   }
   if(name==='exp_register'){
     if(data.p_invite_hash===null&&this.tables.exp_users.some(u=>u.role==='admin'))throw Object.assign(Error('管理员已存在'),{status:400});
     const invite=this.tables.exp_invites?.find(i=>i.token_hash===data.p_invite_hash&&!i.used_at&&i.expires_at>'2026-10-31');
     if(data.p_invite_hash&&!invite)throw Object.assign(Error('邀请无效'),{status:400});
     if(invite)invite.used_at='2026-10-31';
     const [u]=await this.insert('exp_users',{...data.p_user,role:invite?'employee':'admin',display_name:invite?.display_name||data.p_user.display_name,department:invite?.department||'管理',active:true});return u;
   }
   throw Error('Unexpected RPC');
 }
}
