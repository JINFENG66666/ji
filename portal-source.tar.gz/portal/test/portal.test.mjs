import test from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { randomUUID } from 'node:crypto';
import { inflateRawSync } from 'node:zlib';
import ExcelJS from 'exceljs';
import sharp from 'sharp';
import { createApp } from '../app.mjs';
import { passwordHash,passwordMatches,hash,cents,sixMonthsAgo } from '../lib/security.mjs';
import { reviewClaim,distance,inspectImage } from '../lib/review.mjs';
import { extractReceipt } from '../client/ocr.mjs';

const ids={admin:'10000000-0000-4000-8000-000000000001',a:'10000000-0000-4000-8000-000000000002',b:'10000000-0000-4000-8000-000000000003',ca:'20000000-0000-4000-8000-000000000001',cb:'20000000-0000-4000-8000-000000000002',aa:'30000000-0000-4000-8000-000000000001',ab:'30000000-0000-4000-8000-000000000002'};
import { FakeDB } from './support/fake-db.mjs';
async function fixture(t){
 const password=await passwordHash('TestPassword123!');
 const users=[{id:ids.admin,username:'owner',display_name:'管理员',department:'管理',role:'admin',active:true,password_hash:password},{id:ids.a,username:'employee_a',display_name:'张三',department:'销售',role:'employee',active:true,password_hash:password},{id:ids.b,username:'employee_b',display_name:'李四',department:'研发',role:'employee',active:true,password_hash:password}];
 const tokens={};for(const k of ['admin','a','b'])tokens[k]=('session_'+k+'_').padEnd(43,'x');
 const image=await sharp({create:{width:800,height:600,channels:3,background:'#abc'}}).jpeg().toBuffer();
 const atts=['a','b'].map(k=>({id:ids['a'+k],user_id:ids[k],claim_id:ids['c'+k],kind:'payment',file_name:'receipt.jpg',media_id:'employee-expenses/'+k,format:'jpg',sha256:hash(image),original_sha256:hash(image),dhash:'1234567890abcdef',bytes:image.length,width:800,height:600,ocr_text:'',ocr_confidence:85,ocr_status:'complete',fields:{amount:'88.50',date:'2026-10-30'},flags:[],purged_at:null,created_at:'2026-10-30T00:00:00Z'}));
 const db=new FakeDB({exp_users:users,exp_sessions:['admin','a','b'].map(k=>({token_hash:hash(tokens[k]),user_id:ids[k],expires_at:'2027-01-01T00:00:00Z'})),exp_claims:['a','b'].map(k=>({id:ids['c'+k],user_id:ids[k],idempotency_key:randomUUID(),display_name:users.find(u=>u.id===ids[k]).display_name,department:'销售',expense_date:'2026-10-30',description:'测试交通费用',amount_cents:8850,status:'pending',review_note:'',flags:[],created_at:'2026-10-30T00:00:00Z'})),exp_attachments:atts,exp_invites:[],exp_backups:[],exp_audit:[]});
 let downloads=0,removed=0;
 const media={async upload(buf,id){return {public_id:'employee-expenses/'+id};},async download(){downloads++;return image;},async remove(){removed++;}};
 const app=createApp({db,media,origin:'http://localhost',setupToken:'test-only-setup-token',clock:()=>new Date('2026-10-31T04:00:00Z')});
 const server=app.listen(0,'127.0.0.1');await once(server,'listening');t.after(()=>new Promise(r=>server.close(r)));
 const base='http://127.0.0.1:'+server.address().port;
 const request=(path,{as='a',method='GET',body,origin}={})=>fetch(base+path,{method,headers:{...(as?{Cookie:'expense_session='+tokens[as]}:{}),...(body instanceof FormData?{}:body?{'Content-Type':'application/json'}:{}),...(origin?{Origin:origin}:{})},body:body===undefined?undefined:body instanceof FormData?body:JSON.stringify(body)});
 return {db,request,tokens,image,get downloads(){return downloads;},get removed(){return removed;}};
}
test('exact monetary arithmetic and strict value validation',()=>{assert.equal(cents('0.29'),29);assert.equal(cents('1234.56'),123456);for(const value of ['0','-1','NaN','1e3','0.001','1000000.01','=1+1'])assert.throws(()=>cents(value));});
test('password hashing, verification, and incorrect password rejection',async()=>{const p=await passwordHash('Passphrase123!');assert.ok(await passwordMatches('Passphrase123!',p));assert.equal(await passwordMatches('wrong',p),false);assert.notEqual(p,'Passphrase123!');await assert.rejects(()=>passwordHash('short'));});
test('six month retention clamps month ends correctly',()=>{assert.equal(sixMonthsAgo(new Date('2026-08-31T12:00:00Z')).toISOString(),'2026-02-28T12:00:00.000Z');});
test('Chinese invoice and payment amount/date extraction',()=>{
 assert.deepEqual({...extractReceipt('电子发票\n发票号码:12345678901234567890\n开票日期:2026年10月30日\n价税合计(小写)￥128.50','invoice')},{amount:'128.50',date:'2026-10-30',number:'12345678901234567890'});
 assert.equal(extractReceipt('价 税 合计 (小 写 ) : 兰 128.50','invoice').amount,'128.50');
 const p=extractReceipt('微信支付\n支付金额:88.50\n支付时间:2026-10-30 13:25\n交易单号:1234567890123456789012345','payment');assert.equal(p.amount,'88.50');assert.equal(p.date,'2026-10-30');assert.equal(p.time,'13:25');assert.equal(extractReceipt('日期:2026年99月99日','invoice').date,undefined);assert.equal(extractReceipt('微信支付\n支付时间:2026-10-30 13:25','payment').amount,undefined);
});
test('review flags amount/date disagreement and missing invoice without claiming P图 detection',()=>{const f=reviewClaim({amount_cents:1000,expense_date:'2026-10-31'},[{kind:'payment',ocr_status:'complete',ocr_confidence:80,fields:{amount:'11.00',date:'2026-10-30'},flags:[]}]);assert.ok(f.some(x=>x.includes('金额不一致')));assert.ok(f.some(x=>x.includes('日期不一致')));assert.ok(f.some(x=>x.includes('未提供发票')));});
test('valid images are hashed; invalid content and SVG are rejected',async()=>{const b=await sharp({create:{width:800,height:600,channels:3,background:'#fff'}}).png().toBuffer();const i=await inspectImage(b);assert.equal(i.sha256,hash(b));assert.equal(i.dhash.length,16);assert.equal(distance(i.dhash,i.dhash),0);await assert.rejects(()=>inspectImage(Buffer.from('not an image')));await assert.rejects(()=>inspectImage(Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100"></svg>')));});
test('employees only receive their own claim and attachment metadata',async t=>{const f=await fixture(t);const r=await f.request('/api/claims');assert.equal(r.status,200);const j=await r.json();assert.equal(j.claims.length,1);assert.equal(j.claims[0].user_id,ids.a);assert.equal(j.claims[0].attachments[0].id,ids.aa);assert.equal(JSON.stringify(j).includes('password_hash'),false);});
test('forged ownership, employee admin APIs, and private media access are denied',async t=>{const f=await fixture(t);assert.equal((await f.request('/api/attachments/'+ids.ab)).status,404);assert.equal(f.downloads,0);for(const path of ['/api/users','/api/backups','/api/export.xlsx','/api/backup.zip','/api/audit'])assert.equal((await f.request(path)).status,403);assert.equal((await f.request('/api/claims/'+ids.cb+'/review',{method:'PATCH',body:{status:'reviewed'}})).status,403);});
test('no-session, expired-session, and disabled-account private requests are denied',async t=>{const f=await fixture(t);assert.equal((await f.request('/api/claims',{as:null})).status,401);f.db.tables.exp_users.find(u=>u.id===ids.a).active=false;assert.equal((await f.request('/api/attachments/'+ids.aa)).status,401);});
test('admin sees all claims and can review while employee cannot escalate role',async t=>{const f=await fixture(t);const j=await (await f.request('/api/claims',{as:'admin'})).json();assert.equal(j.claims.length,2);assert.equal((await f.request('/api/claims/'+ids.ca+'/review',{as:'admin',method:'PATCH',body:{status:'returned',note:''}})).status,400);assert.equal((await f.request('/api/claims/'+ids.ca+'/review',{as:'admin',method:'PATCH',body:{status:'reviewed',note:'已人工核对'}})).status,200);assert.equal(f.db.tables.exp_claims[0].status,'reviewed');});
test('submission ownership and idempotency prevent reusing another employee image or double counting',async t=>{const f=await fixture(t);const base={expense_date:'2026-10-30',description:'打车',amount:'88.50',idempotency_key:randomUUID(),attachments:[ids.ab]};assert.equal((await f.request('/api/claims',{method:'POST',body:base})).status,404);f.db.tables.exp_attachments[0].claim_id=null;const body={...base,attachments:[ids.aa]};assert.equal((await f.request('/api/claims',{method:'POST',body})).status,201);assert.equal((await f.request('/api/claims',{method:'POST',body})).status,201);assert.equal(f.db.tables.exp_claims.filter(c=>c.idempotency_key===body.idempotency_key).length,1);});
test('cross-origin writes and invalid dates are blocked',async t=>{const f=await fixture(t);assert.equal((await f.request('/api/login',{method:'POST',origin:'https://evil.invalid',body:{username:'employee_a',password:'TestPassword123!'}})).status,403);assert.equal((await f.request('/api/claims',{method:'POST',body:{expense_date:'2026-02-31'}})).status,400);});
test('backup must complete and be confirmed, and only six month old included media is purged',async t=>{const f=await fixture(t);const id=randomUUID();await f.db.insert('exp_backups',{id,attachment_ids:[ids.aa],completed:false});assert.equal((await f.request('/api/backups/'+id+'/confirm',{as:'admin',method:'POST',body:{confirmation:'已核对备份可打开'}})).status,400);assert.equal((await f.request('/api/backups/'+id+'/purge',{as:'admin',method:'POST',body:{confirmation:'删除已备份的过期图片'}})).status,400);f.db.tables.exp_backups[0].completed=true;assert.equal((await f.request('/api/backups/'+id+'/confirm',{as:'admin',method:'POST',body:{confirmation:'已核对备份可打开'}})).status,200);assert.equal((await (await f.request('/api/backups/'+id+'/purge',{as:'admin',method:'POST',body:{confirmation:'删除已备份的过期图片'}})).json()).count,0);f.db.tables.exp_attachments[0].created_at='2026-03-01T00:00:00Z';const result=await (await f.request('/api/backups/'+id+'/purge',{as:'admin',method:'POST',body:{confirmation:'删除已备份的过期图片'}})).json();assert.equal(result.count,1);assert.equal(f.removed,1);assert.equal(f.db.tables.exp_claims.length,2);});
function unzipSmall(buffer){
 const end=buffer.lastIndexOf(Buffer.from([0x50,0x4b,0x05,0x06]));assert.ok(end>=0,'ZIP central directory is present');
 const count=buffer.readUInt16LE(end+10);let at=buffer.readUInt32LE(end+16);const files=new Map();
 for(let i=0;i<count;i++){
   assert.equal(buffer.readUInt32LE(at),0x02014b50);const method=buffer.readUInt16LE(at+10),size=buffer.readUInt32LE(at+20),nameLen=buffer.readUInt16LE(at+28),extra=buffer.readUInt16LE(at+30),comment=buffer.readUInt16LE(at+32),local=buffer.readUInt32LE(at+42);
   const name=buffer.subarray(at+46,at+46+nameLen).toString();const start=local+30+buffer.readUInt16LE(local+26)+buffer.readUInt16LE(local+28),raw=buffer.subarray(start,start+size);
   files.set(name,method===8?inflateRawSync(raw):raw);at+=46+nameLen+extra+comment;
 }
 return files;
}
test('full backup recovers original stored bytes, six-column workbook and matching integrity manifest',async t=>{
 const f=await fixture(t);const r=await f.request('/api/backup.zip',{as:'admin'});assert.equal(r.status,200);const files=unzipSmall(Buffer.from(await r.arrayBuffer()));
 const manifest=JSON.parse(files.get('manifest.json').toString());assert.equal(manifest.files.length,2);
 for(const file of manifest.files)assert.equal(hash(files.get(file.path)),file.sha256);
 assert.ok(files.get('MANIFEST.SHA256').toString().startsWith(hash(files.get('manifest.json'))));
 const w=new ExcelJS.Workbook();await w.xlsx.load(files.get('expenses.xlsx'));assert.deepEqual(w.worksheets[0].getRow(1).values.slice(1),['时间','部门','人员姓名','事项','金额','发票照片或支付记录']);assert.equal(w.worksheets[0].getCell('E2').value,88.5);
 await new Promise(r=>setTimeout(r,20));assert.equal(f.db.tables.exp_backups[0].completed,true);assert.equal(f.downloads,2);
});
