import { build } from 'esbuild';
import { mkdir, cp, copyFile, readdir, readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import path from 'node:path';
const require = createRequire(import.meta.url);
await mkdir('dist/vendor', {recursive:true});
await mkdir('dist/tessdata', {recursive:true});
await cp('public', 'dist', {recursive:true});
const version=createHash('sha256');for(const file of ['client/app.mjs','client/ocr.mjs','client/vendor/fp-extract.ts','public/style.css','package.json'])version.update(await readFile(file));const tag=version.digest('hex').slice(0,12);
await build({entryPoints:['client/app.mjs','client/ocr.mjs'],outdir:'dist',bundle:true,format:'esm',target:'es2022',minify:true,legalComments:'eof',define:{__BUILD_VERSION__:JSON.stringify(tag)}});
let html=await readFile('dist/index.html','utf8');html=html.replace('src="/app.js"',`src="/app.js?v=${tag}"`).replace('href="/style.css"',`href="/style.css?v=${tag}"`);await writeFile('dist/index.html',html);
const tesseractDir=path.dirname(require.resolve('tesseract.js/package.json'));
await copyFile(path.join(tesseractDir,'dist/worker.min.js'),'dist/vendor/worker.min.js');
const tesseractRequire=createRequire(path.join(tesseractDir,'package.json'));
const coreDir=path.dirname(tesseractRequire.resolve('tesseract.js-core/package.json'));
for(const file of await readdir(coreDir)) if(/\.wasm(\.js)?$/.test(file)) await copyFile(path.join(coreDir,file),'dist/vendor/'+file);
for(const lang of ['eng','chi_sim']) {
  const dir=path.dirname(require.resolve(`@tesseract.js-data/${lang}/package.json`));
  await copyFile(path.join(dir,'4.0.0_best_int',`${lang}.traineddata.gz`),`dist/tessdata/${lang}.traineddata.gz`);
}
console.log('Built app with self-hosted OCR worker, WASM, and Chinese/English models.');
