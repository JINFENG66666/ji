// Local QA only: synthetic records and in-memory media, never production credentials.
import { createApp } from '../app.mjs';
import { FakeDB } from '../test/support/fake-db.mjs';
import { passwordHash,hash } from '../lib/security.mjs';
import { randomUUID } from 'node:crypto';
import sharp from 'sharp';
const password=await passwordHash('LocalDemo123!');
const admin={id:randomUUID(),username:'demo_admin',display_name:'演示管理员',department:'管理',role:'admin',active:true,password_hash:password};
const employees=['演示张三','演示李四','演示王五'].map((name,i)=>({id:randomUUID(),username:'demo_employee'+i,display_name:name,department:i%2?'研发部':'销售部',role:'employee',active:true,password_hash:password}));
const image=await sharp({create:{width:1200,height:800,channels:3,background:'#e0eadc'}}).jpeg().toBuffer();
const files=new Map();const claims=[],attachments=[];
for(let i=0;i<7;i++){
 const u=employees[i%3],id=randomUUID(),a=randomUUID(),media_id='demo/'+a;files.set(media_id,image);
 claims.push({id,user_id:u.id,idempotency_key:randomUUID(),expense_date:'2026-10-30',expense_time:'14:25:00',display_name:u.display_name,department:u.department,description:['客户拜访交通费用','项目资料打印','办公耗材采购'][i%3],amount_cents:[8850,12850,36000][i%3],status:i===0?'reviewed':'pending',review_note:'',flags:i===1?['填写金额与发票识别金额不一致']:[],created_at:'2026-10-30T00:00:00Z'});
 attachments.push({id:a,user_id:u.id,claim_id:id,kind:'payment',file_name:'demo-receipt.jpg',media_id,format:'jpg',sha256:hash(image),original_sha256:hash(image),dhash:'1234567890abcdef',bytes:image.length,width:1200,height:800,ocr_status:'complete',ocr_confidence:86,fields:{amount:'88.50',date:'2026-10-30'},flags:[],purged_at:null,created_at:'2026-10-30T00:00:00Z'});
}
const db=new FakeDB({exp_users:[admin,...employees],exp_claims:claims,exp_attachments:attachments,exp_sessions:[],exp_invites:[],exp_backups:[],exp_audit:[]});
const media={async upload(buffer,id){const public_id='demo/'+id;files.set(public_id,buffer);return {public_id};},async download(a){return files.get(a.media_id);},async remove(a){files.delete(a.media_id);}};
const port=Number(process.env.PORT||3011);
createApp({db,media,origin:'http://127.0.0.1:'+port,setupToken:'disabled-preview'}).listen(port,'127.0.0.1',()=>console.log('Local synthetic-data preview: http://127.0.0.1:'+port));
