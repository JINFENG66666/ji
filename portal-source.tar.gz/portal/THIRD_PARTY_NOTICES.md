# Open-source components

Chinese invoice and payment screenshot field extraction in `client/vendor/fp-extract.ts` is adapted from FP 报销信息整理识别系统:
https://github.com/zhangdexuan/fp-reimbursement-system
Source revision: 2000e2d305300db7c57e859c1de8250b1ba12e62
Original file: src/utils/invoiceOcr.ts; payment date normalization: src/utils/reimbursement.ts.
Original MIT license is retained at licenses/FP-MIT.txt. The portal adds employee grouping, private cloud media, access checks, retention/backup, and browser-only OCR execution; it does not call the upstream standalone OCR service.

Other dependencies retain their published licenses in their packages. Tesseract.js, Tesseract.js-core and language models are distributed as required by their upstream licenses.
