# 员工报销汇总网站

员工上传发票/支付截图，确认日期、时间、事项和金额。管理员按人员查看总金额、申报次数及分项，人工记录复核结果。网站不执行打款。

## 部署

- Node.js 22+；已固定全部直接依赖及 pnpm 锁文件。
- Render Free：`pnpm install --frozen-lockfile --ignore-scripts && pnpm build`，启动 `pnpm start`。
- 仅在新 Supabase 项目中执行 `db/schema.sql`，再运行下方权限核验查询。项目不向浏览器暴露数据库管理密钥，公共角色不可读取业务表。
- 在 Render 环境变量内配置 `.env.example` 列出的键；密钥不写入代码仓库。
- 管理员通过 `/#setup=<ADMIN_SETUP_TOKEN>` 初始化唯一账号。员工只能使用管理员生成的单次邀请开通账号。初始化完成后，旧初始化链接不再可以创建管理员。

```sql
select c.relname, c.relrowsecurity,
  has_table_privilege('anon', c.oid, 'select') as anon_can_read,
  has_table_privilege('authenticated', c.oid, 'select') as auth_can_read
from pg_class c join pg_namespace n on n.oid=c.relnamespace
where n.nspname='public' and c.relname like 'exp_%';
```

## 免费运行与检查范围

- 浏览器使用自托管 Tesseract 中文/英文模型；不调用付费 OCR 或大模型。
- 图片先检查原始文件元数据和哈希，再保存不超过 750KB 的清晰 JPEG 副本。原图请由员工自行保存，ZIP 备份导出的是这些压缩副本。
- 检查包括完全重复、近似图像、金额/日期差异、低置信度、低分辨率和部分编辑软件元数据。相似图像可能只是同一票据模板；元数据可被修改或删除。所有标记仅辅助人工复核，不能证明发票真实或判断是否 P 图。
- OCR 在员工浏览器执行，后台注明该来源，不将客户端结果宣称为独立验真。
- 免费服务有使用额度及休眠限制；代码没有自动升级或付费操作。图片按上限测算：6000 张压缩副本不超过约 4.5GB，实际占用取决于图片内容。容量、流量需以平台实时额度为准。

## 备份与半年归档

完整 ZIP 含六列表格、按人汇总、所有未归档图片（包括未提交的临时凭证）、清单和 SHA-256 校验文件。完成下载、解压并确认可打开后，管理员才能确认备份。清理时还需输入完整确认语句；仅删除这份备份中、上传超过六个月的线上图片。申报记录和金额汇总保留。

复核状态“需补充”保留原申报和备注；员工需要更正时先联系管理员，避免重复新增同一费用。

## 验证

`pnpm test` 使用虚构数据在回环地址测试权限隔离、金额/日期、图片校验、重复提交、备份下载、归档保护。测试不访问真实 Supabase 或 Cloudinary。真实服务接入后还需验证私有图片上传/读取、重启后数据保持以及管理员初始账号设置。

开源复用与许可证见 `THIRD_PARTY_NOTICES.md`。
